[
	{
		"step":1,
		"start_url": "https://pav1.services-fm.net/ExtranetPremiumApporteur/login",
		"method": "GET",
		"type": "script",
		"snippet": "script/step01.js"
	},
	{
		"step":2,
		"start_url": "https://pav1.services-fm.net/ExtranetPremiumApporteur/extranet",
		"method": "POST",
		"type": "script",
		"snippet": "script/step02.js"
	},
	{
		"step":3,
		"start_url": "https://pav1.services-fm.net/ExtranetPremiumProspect/compo",
		"method": "GET",
		"type": "script",
		"snippet": "script/step03.js"
	},
	{
		"step":4,
		"start_url": "https://pav1.services-fm.net/ExtranetPremiumProspect/quest",
		"method": "GET",
		"type": "script",
		"snippet": "script/step04.js"
	},
	{
		"step":5,
		"start_url": "https://pav1.services-fm.net/ExtranetPremiumProspect/prop",
		"method": "GET",
		"type": "script",
		"snippet": "script/step05.js",
		"downloadFiles": [{"url": "https://pav1.services-fm.net/ExtranetPremiumProspect/download?action=gie&code=WSHW11", "name": "garanties.pdf"}]
	},
	{
		"step":6,
		"start_url": "https://pav1.services-fm.net/ExtranetPremiumProspect/recap",
		"method": "GET",
		"type": "script",
		"snippet": "script/step06.js",
		"downloadFiles": [{"url": "https://pav1.services-fm.net/ExtranetPremiumProspect/download?action=devis", "name": "devis.pdf"}]
	},
	{
		"step": 7,
		"start_url": "https://pav1.services-fm.net/ExtranetPremiumProspect/download?action=devis",
		"method": "GET",
		"type": "script",
		"snippet": "script/step07.js"
	},
	{
		"step":8,
		"start_url": "https://pav1.services-fm.net/ExtranetPremiumApporteur/login",
		"type": "sequence",
		"method": "GET",
		"snippet": "sequence/sequence07.js"
	}
]