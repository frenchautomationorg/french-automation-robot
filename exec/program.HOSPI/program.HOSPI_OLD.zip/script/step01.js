$("#id").val("{ENV|F_LOGIN}");
$("#mdp").val("{ENV|F_PASSWORD}");
$("#login-connexion").submit();