setTimeout( function () { var id = $(".questionsPersCtn").attr('id'); nextQuestion(100, 228, id, 2);  setTimeout( function () { $("#valid_quest").click(); }, 2000); }, 4000);
