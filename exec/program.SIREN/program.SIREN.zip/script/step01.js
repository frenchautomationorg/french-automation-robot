$("#rsQuery").val("{ENV|raison_sociale}");
$("#btn-search").click()