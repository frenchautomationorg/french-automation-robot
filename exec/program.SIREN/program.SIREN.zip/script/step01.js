$("#rsQuery").val("{ENV|F_NOM}");
$("#btn-search").click()