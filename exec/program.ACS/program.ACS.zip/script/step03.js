$("#cp").val("{ENV|F_CP}");
$("#date_naissance").val("{ENV|F_ANNEE_NAISSANCE}");
$("#bt_valid")[0].onclick();
$("#bt_valid").click();