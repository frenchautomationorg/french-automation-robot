$("#identifiant").val("{ENV|F_LOGIN}");
$("#mot_passe").val("{ENV|F_PASSWORD}");
$("#form_extranet").submit();